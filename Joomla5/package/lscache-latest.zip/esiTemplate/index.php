<?php
// No direct access.
defined('_JEXEC') or die;
// Output as HTML5
$this->setHtml5(true);
?>
<jdoc:include type="modules" name="esi" />